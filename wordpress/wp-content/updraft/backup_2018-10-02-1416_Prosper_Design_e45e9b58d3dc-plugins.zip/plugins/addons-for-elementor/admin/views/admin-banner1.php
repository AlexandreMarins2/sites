<?php

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

?>

<div id="lae-banner-wrap">

    <div id="lae-banner" class="lae-banner-sticky">
        <h2><span><?php echo __('Livemesh Addons for Elementor', 'livemesh-el-addons'); ?></span><?php echo __('Plugin Documentation', 'livemesh-el-addons') ?></h2>
    </div>

</div>